function onlinecheck(that){
    if(that.value=="onlinePay"){
        document.getElementById("ifyes").style.display="block";
    }
    else{
        document.getElementById("ifyes").style.display="none";
    }
}
